<?php
if (!defined('ABSPATH')) exit;

/**
 * Fetches content from URLs and creates WordPress posts.
 */
function fetch_and_create_posts($urls) {
    if (!is_array($urls)) return;

    foreach ($urls as $url) {
        $response = wp_remote_get($url);
        if (is_wp_error($response)) continue;
        
        $html = wp_remote_retrieve_body($response);
        if (empty($html)) continue;
        
        libxml_use_internal_errors(true);
        $doc = new DOMDocument();
        $doc->loadHTML($html);
        libxml_clear_errors();
        
        $xpath = new DOMXPath($doc);
        
        // Extract title
        $title = '';
        $h1 = $xpath->query('//h1');
        if ($h1->length > 0) $title = trim($h1->item(0)->textContent);
        if (empty($title)) continue;
        
        // Extract image
        $images = $xpath->query('//img');
        $featured_image_url = '';
        foreach ($images as $img) {
            if (stripos($img->getAttribute('alt'), 'logo') === false) {
                $featured_image_url = $img->getAttribute('src');
                break;
            }
        }

        // Download and set featured image
        $featured_image_id = '';
        if (!empty($featured_image_url)) {
            $image_id = media_sideload_image($featured_image_url, 0, '', 'id');
            if (!is_wp_error($image_id)) $featured_image_id = $image_id;
        }

        // Extract content in the correct sequence
        $content = '';
        
        // Fetch all relevant elements (p, ul) in order
        $body = $xpath->query('//body//*[self::p or self::ul][not(ancestor::form)]');
        foreach ($body as $element) {
            if ($element->nodeName === 'p') {
                $text = trim($element->nodeValue);
                $text = preg_replace('/\s+/', ' ', $text); // Normalize whitespace
                $content .= '<p>' . $text . '</p>';
            } elseif ($element->nodeName === 'ul') {
                $content .= '<ul>';
                $items = $element->getElementsByTagName('li');
                foreach ($items as $li) {
                    $text = trim($li->nodeValue);
                    $text = preg_replace('/\s+/', ' ', $text); // Normalize whitespace
                    $content .= '<li>' . $text . '</li>';
                }
                $content .= '</ul>';
            }
        }

        // Add featured image at the top (without heading)
        if ($featured_image_id) {
            $content = wp_get_attachment_image($featured_image_id, 'full') . $content;
        }

        // Create post
        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'post'
        ]);

        if ($post_id) {
            $post_slug = get_post_field('post_name', $post_id);
            $form_id = create_forminator_form($post_slug, $title, $html);
            if ($form_id) {
                // Add custom text before the form as an H2 heading
                $form_text = '<h2>Download ' . $title . ' Whitepaper</h2>';
                $content .= $form_text . '[formidable id="' . $form_id . '"]';
                wp_update_post(['ID' => $post_id, 'post_content' => $content]);
            }
        }
    }
}